<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class Token {
    private $secretKey = 'ptBuHcBZ5CCLji73q0MygvHvKAO9Lq4I';

    function create(array $payload) : string {
        $token = JWT::encode($tokenPayload, $this->secretKey, 'HS256');

        return $token; 
    }

    function payload($string) : array {
        $decodedToken = JWT::decode($token, new Key($secretKey, 'HS256'));
        
        return json_encode($decodedToken, true);
    }
}