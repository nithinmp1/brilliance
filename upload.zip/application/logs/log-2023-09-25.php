ERROR - 2023-09-25 12:36:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Pages_model C:\xampp\htdocs\brilliance\system\core\Loader.php 348
ERROR - 2023-09-25 12:38:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Pages_model C:\xampp\htdocs\brilliance\system\core\Loader.php 348
ERROR - 2023-09-25 12:38:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Pages_model C:\xampp\htdocs\brilliance\system\core\Loader.php 348
ERROR - 2023-09-25 12:38:45 --> Severity: error --> Exception: Unable to locate the model you have specified: Pages_model C:\xampp\htdocs\brilliance\system\core\Loader.php 348
ERROR - 2023-09-25 12:38:45 --> Severity: error --> Exception: Unable to locate the model you have specified: Pages_model C:\xampp\htdocs\brilliance\system\core\Loader.php 348
ERROR - 2023-09-25 12:38:45 --> Severity: error --> Exception: Unable to locate the model you have specified: Pages_model C:\xampp\htdocs\brilliance\system\core\Loader.php 348
ERROR - 2023-09-25 12:38:45 --> Severity: error --> Exception: Unable to locate the model you have specified: Pages_model C:\xampp\htdocs\brilliance\system\core\Loader.php 348
ERROR - 2023-09-25 12:38:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Pages_model C:\xampp\htdocs\brilliance\system\core\Loader.php 348
ERROR - 2023-09-25 12:41:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Pages_model C:\xampp\htdocs\brilliance\system\core\Loader.php 348
ERROR - 2023-09-25 12:42:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Pages_model C:\xampp\htdocs\brilliance\system\core\Loader.php 348
ERROR - 2023-09-25 12:43:44 --> 404 Page Not Found: api/V1/quiz
ERROR - 2023-09-25 12:44:48 --> 404 Page Not Found: api/V1/quiz
ERROR - 2023-09-25 12:48:11 --> Severity: error --> Exception: Monolog\Logger::info(): Argument #2 ($context) must be of type array, null given, called in C:\xampp\htdocs\brilliance\application\libraries\Guzzle.php on line 27 C:\xampp\htdocs\brilliance\vendor\monolog\monolog\src\Monolog\Logger.php 591
ERROR - 2023-09-25 12:49:21 --> Severity: error --> Exception: Call to a member function getCartItems() on null C:\xampp\htdocs\brilliance\application\core\MY_Controller.php 27
ERROR - 2023-09-25 12:50:08 --> Severity: error --> Exception: Undefined constant "MY_LANGUAGE_ABBR" C:\xampp\htdocs\brilliance\application\views\templates\crow\_parts\header.php 2
ERROR - 2023-09-25 12:50:10 --> Severity: error --> Exception: Undefined constant "MY_LANGUAGE_ABBR" C:\xampp\htdocs\brilliance\application\views\templates\crow\_parts\header.php 2
ERROR - 2023-09-25 12:51:02 --> Severity: error --> Exception: Undefined constant "LANG_URL" C:\xampp\htdocs\brilliance\application\views\templates\crow\_parts\header.php 11
ERROR - 2023-09-25 12:51:34 --> Severity: Warning --> Undefined property: stdClass::$mobile C:\xampp\htdocs\brilliance\application\controllers\Api\Account.php 106
