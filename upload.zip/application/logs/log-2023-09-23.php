<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-23 21:24:59 --> 404 Page Not Found: /index
ERROR - 2023-09-23 21:24:59 --> 404 Page Not Found: /index
ERROR - 2023-09-23 21:24:59 --> 404 Page Not Found: /index
ERROR - 2023-09-23 21:24:59 --> 404 Page Not Found: /index
ERROR - 2023-09-23 21:24:59 --> 404 Page Not Found: /index
ERROR - 2023-09-23 21:24:59 --> 404 Page Not Found: /index
ERROR - 2023-09-23 21:24:59 --> 404 Page Not Found: /index
ERROR - 2023-09-23 21:24:59 --> 404 Page Not Found: /index
ERROR - 2023-09-23 21:24:59 --> 404 Page Not Found: /index
ERROR - 2023-09-23 21:24:59 --> 404 Page Not Found: /index
ERROR - 2023-09-23 21:24:59 --> 404 Page Not Found: /index
ERROR - 2023-09-23 21:24:59 --> 404 Page Not Found: /index
