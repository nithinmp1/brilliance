<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-24 16:57:13 --> 404 Page Not Found: /index
ERROR - 2023-09-24 16:57:13 --> 404 Page Not Found: /index
ERROR - 2023-09-24 16:57:13 --> 404 Page Not Found: /index
ERROR - 2023-09-24 16:57:13 --> 404 Page Not Found: /index
ERROR - 2023-09-24 16:57:13 --> 404 Page Not Found: /index
ERROR - 2023-09-24 16:57:13 --> 404 Page Not Found: /index
ERROR - 2023-09-24 16:57:13 --> 404 Page Not Found: /index
ERROR - 2023-09-24 16:57:14 --> 404 Page Not Found: /index
ERROR - 2023-09-24 16:57:14 --> 404 Page Not Found: /index
ERROR - 2023-09-24 16:57:14 --> 404 Page Not Found: /index
ERROR - 2023-09-24 16:57:14 --> 404 Page Not Found: /index
ERROR - 2023-09-24 16:57:14 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:11:01 --> Severity: error --> Exception: Undefined constant "options" C:\xampp\htdocs\brilliance\application\views\templates\crow\home.php 739
ERROR - 2023-09-24 17:11:02 --> Severity: error --> Exception: Undefined constant "options" C:\xampp\htdocs\brilliance\application\views\templates\crow\home.php 739
ERROR - 2023-09-24 17:11:15 --> Severity: error --> Exception: Undefined constant "options" C:\xampp\htdocs\brilliance\application\views\templates\crow\home.php 739
ERROR - 2023-09-24 17:12:10 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:12:10 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:12:10 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:12:10 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:12:10 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:12:11 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:12:11 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:12:11 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:12:11 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:12:11 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:12:11 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:12:11 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:07 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:07 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:07 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:07 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:07 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:07 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:07 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:07 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:07 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:07 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:07 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:07 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:37 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:37 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:37 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:37 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:37 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:37 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:37 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:37 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:37 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:37 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:37 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:37 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:54 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:54 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:54 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:54 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:54 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:54 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:54 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:54 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:54 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:54 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:54 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:14:55 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:03 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:03 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:03 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:03 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:03 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:03 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:03 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:03 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:03 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:03 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:03 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:03 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:06 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:06 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:06 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:06 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:06 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:06 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:06 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:06 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:07 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:07 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:07 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:16:07 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:18:15 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:18:15 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:18:15 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:18:16 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:18:16 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:18:16 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:18:16 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:18:16 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:18:16 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:18:16 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:18:16 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:18:16 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:19:00 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:19:00 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:19:00 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:19:00 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:19:00 --> 404 Page Not Found: /index
ERROR - 2023-09-24 17:32:51 --> Severity: Warning --> Undefined variable $updateUrl C:\xampp\htdocs\brilliance\application\modules\admin\views\admin_templates\crow\_parts\footer.php 75
ERROR - 2023-09-24 17:32:51 --> Severity: Warning --> Undefined property: CI::$action C:\xampp\htdocs\brilliance\application\third_party\MX\Controller.php 59
ERROR - 2023-09-24 17:32:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\brilliance\application\modules\admin\views\admin_templates\crow\_parts\footer.php 114
ERROR - 2023-09-24 17:49:42 --> Severity: Warning --> Undefined variable $updateUrl C:\xampp\htdocs\brilliance\application\modules\admin\views\admin_templates\crow\_parts\footer.php 75
ERROR - 2023-09-24 17:49:42 --> Severity: Warning --> Undefined property: CI::$action C:\xampp\htdocs\brilliance\application\third_party\MX\Controller.php 59
ERROR - 2023-09-24 17:49:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\brilliance\application\modules\admin\views\admin_templates\crow\_parts\footer.php 114
ERROR - 2023-09-24 19:31:32 --> Severity: Warning --> Undefined array key "HTTP_ACCEPT_LANGUAGE" C:\xampp\htdocs\brilliance\application\controllers\Api\Account.php 79
ERROR - 2023-09-24 19:34:49 --> Severity: Warning --> Undefined variable $language C:\xampp\htdocs\brilliance\application\controllers\Api\Account.php 82
ERROR - 2023-09-24 19:50:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\brilliance\application\controllers\Api\Account.php 81
ERROR - 2023-09-24 19:50:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\brilliance\application\controllers\Api\Account.php 82
ERROR - 2023-09-24 22:24:36 --> Severity: Warning --> Undefined property: stdClass::$mobile C:\xampp\htdocs\brilliance\application\controllers\Api\Account.php 80
ERROR - 2023-09-24 22:27:42 --> Severity: Warning --> Undefined property: stdClass::$score C:\xampp\htdocs\brilliance\application\controllers\Api\Account.php 107
ERROR - 2023-09-24 22:38:03 --> Severity: Warning --> Undefined property: CI::$data C:\xampp\htdocs\brilliance\application\third_party\MX\Controller.php 59
