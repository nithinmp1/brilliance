-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: brilliance
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accessmanagement`
--

DROP TABLE IF EXISTS `accessmanagement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accessmanagement` (
  `accessManagement_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `access` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`accessManagement_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accessmanagement`
--

LOCK TABLES `accessmanagement` WRITE;
/*!40000 ALTER TABLE `accessmanagement` DISABLE KEYS */;
INSERT INTO `accessmanagement` VALUES (1,'Manager','{\"staff\":[\"add\",\"edit\",\"delete\"]}');
/*!40000 ALTER TABLE `accessmanagement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `active_pages`
--

DROP TABLE IF EXISTS `active_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `active_pages` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `active_pages`
--

LOCK TABLES `active_pages` WRITE;
/*!40000 ALTER TABLE `active_pages` DISABLE KEYS */;
INSERT INTO `active_pages` VALUES (1,'blog',1);
/*!40000 ALTER TABLE `active_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `branch` (
  `branch_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch`
--

LOCK TABLES `branch` WRITE;
/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
INSERT INTO `branch` VALUES (1,'John','5gg','10','86506','86426','2023-09-25 10:31:45','2023-09-25 10:31:56'),(2,'John','5','10','86506','86426','2023-09-25 10:31:53','2023-09-25 10:31:53');
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brands` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `explanation`
--

DROP TABLE IF EXISTS `explanation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `explanation` (
  `explanation_id` int NOT NULL AUTO_INCREMENT,
  `explanation` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`explanation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `explanation`
--

LOCK TABLES `explanation` WRITE;
/*!40000 ALTER TABLE `explanation` DISABLE KEYS */;
INSERT INTO `explanation` VALUES (1,'exp 1'),(2,'exp2'),(3,'Eight persons sit in a parallel row such that four persons-A, B, C and D sit in a row 1 and face north and the remaining four\npersons- P, Q, R and S sit in a row 2 and face south. The persons sit in a row 1 face the person sits in a row 2 and vice versa. Each\nperson belongs to different countries i.e. Japan, USA, Canada, Egypt, Cuba , Iran, Italy and China. All the information is not\nnecessarily in the same order.\nThe one who belongs to Ira\nn sits second to the left of R. Only one person sits between B and A. B faces neither R nor the one who belongs to Iran. The one who\nbelongs to Egypt sits to the immediate right of A and sits at the extreme end. S faces C who sits second to the right of the one who\nfaces the one who belongs to Japan. P faces the one who belongs to Cuba. D sits to the left of the one who belongs to Canada. Q and\nthe one who belongs to Italy didn’t sit in the same row. The one who belongs to china doesn’t sit adjacent to S.'),(4,NULL);
/*!40000 ALTER TABLE `explanation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `history` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `activity` varchar(255) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `time` int unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history`
--

LOCK TABLES `history` WRITE;
/*!40000 ALTER TABLE `history` DISABLE KEYS */;
/*!40000 ALTER TABLE `history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question` (
  `question_id` int NOT NULL AUTO_INCREMENT,
  `question` text COLLATE utf8mb4_unicode_ci,
  `option1` text COLLATE utf8mb4_unicode_ci,
  `option2` text COLLATE utf8mb4_unicode_ci,
  `option3` text COLLATE utf8mb4_unicode_ci,
  `option4` text COLLATE utf8mb4_unicode_ci,
  `option5` text COLLATE utf8mb4_unicode_ci,
  `answer` text COLLATE utf8mb4_unicode_ci,
  `stream_id` int DEFAULT NULL,
  `prilims` smallint DEFAULT NULL,
  `main` smallint DEFAULT NULL,
  `sslc` smallint DEFAULT NULL,
  `hsc` smallint DEFAULT NULL,
  `degree` smallint DEFAULT NULL,
  `subject_id` smallint DEFAULT NULL,
  `section_id` smallint DEFAULT NULL,
  `topic` smallint DEFAULT NULL,
  `model` smallint DEFAULT NULL,
  `have_explanation` smallint DEFAULT NULL,
  `explanation_id` smallint DEFAULT NULL,
  `have_image` smallint DEFAULT NULL,
  `negative_mark` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mark` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lang` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled_for_quiz` smallint DEFAULT NULL,
  `question_type` smallint DEFAULT NULL,
  `created_by` smallint DEFAULT NULL,
  `status` smallint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES (1,'കുളചൃൽ യുദ്ധം നടന്ന വർഷം','1747','1758','1767','1792',NULL,'option1',6,0,0,0,0,0,4,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:21:55','2023-09-23 17:21:55'),(2,'സവാതന്ത്ര്യപൂർവ്വ ഭാരതത്തിൽ ദാരിദ്രരരഖ എന്ന ആശയം ഉയർത്തിക്കാണ്ടുവന്നത് ആര്','ഗാന്ധിജി  ','ജവഹർലാൽ','ദാദാഭായ് നവരറാജി','രവീന്ദ്രനാഥ ടാരഗാർ',NULL,'option2',6,0,0,0,0,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:21:55','2023-09-23 17:21:55'),(3,'സുഭാഷ് ചന്ദ്രര ാസിക്ന രനതാജി എന്നു വിരശഷിപ്പിചൃത്','ഗാന്ധിജി','ടാരഗാർ','രഗാപാല കൃഷ്ണ രഗാഖക്ല','വിൻസ്റ്റൺ ചർചൃിൽ',NULL,'option1',6,0,0,0,0,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:21:55','2023-09-23 17:21:55'),(4,'നിസ്സഹകരണ പ്രസ്ഥാനം പിൻവലികാനുള്ള കാരണം എന്താണ','വാഗൺ ട്രാജഡി','ജാലിയൻവാലാ ാഗ്','കാരകാരി ക്ട്രയിൻ സംഭവ','ചൗരി ചൗര സംഭവം',NULL,'option4',6,0,0,0,1,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:21:55','2023-09-23 17:21:55'),(5,'യൂണിയനും സംസ്ഥാനങ്ങൾക്കം രവണ്ടിയുള്ള പബ്ലിക് സർവീസ് കമ്മീഷനുകക്ള കുറിചൃ് പ്രതിപാദിക്കന്ന ആർട്ടികിൾ','312','315','316','317',NULL,'option2',6,0,0,0,0,0,2,3,0,1,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:21:55','2023-09-23 17:21:55'),(6,'കുളചൃൽ യുദ്ധം നടന്ന വർഷം','1747','1758','1767','1792',NULL,'option1',6,0,0,0,0,0,4,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:27:35','2023-09-23 17:27:35'),(7,'സവാതന്ത്ര്യപൂർവ്വ ഭാരതത്തിൽ ദാരിദ്രരരഖ എന്ന ആശയം ഉയർത്തിക്കാണ്ടുവന്നത് ആര്','ഗാന്ധിജി  ','ജവഹർലാൽ','ദാദാഭായ് നവരറാജി','രവീന്ദ്രനാഥ ടാരഗാർ',NULL,'option2',6,0,0,0,0,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:27:35','2023-09-23 17:27:35'),(8,'സുഭാഷ് ചന്ദ്രര ാസിക്ന രനതാജി എന്നു വിരശഷിപ്പിചൃത്','ഗാന്ധിജി','ടാരഗാർ','രഗാപാല കൃഷ്ണ രഗാഖക്ല','വിൻസ്റ്റൺ ചർചൃിൽ',NULL,'option1',6,0,0,0,0,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:27:35','2023-09-23 17:27:35'),(9,'നിസ്സഹകരണ പ്രസ്ഥാനം പിൻവലികാനുള്ള കാരണം എന്താണ','വാഗൺ ട്രാജഡി','ജാലിയൻവാലാ ാഗ്','കാരകാരി ക്ട്രയിൻ സംഭവ','ചൗരി ചൗര സംഭവം',NULL,'option4',6,0,0,0,1,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:27:35','2023-09-23 17:27:35'),(10,'യൂണിയനും സംസ്ഥാനങ്ങൾക്കം രവണ്ടിയുള്ള പബ്ലിക് സർവീസ് കമ്മീഷനുകക്ള കുറിചൃ് പ്രതിപാദിക്കന്ന ആർട്ടികിൾ','312','315','316','317',NULL,'option2',6,0,0,0,0,0,2,3,0,1,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:27:35','2023-09-23 17:27:35'),(11,'കുളചൃൽ യുദ്ധം നടന്ന വർഷം','1747','1758','1767','1792',NULL,'option1',6,0,0,0,0,0,4,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:28:36','2023-09-23 17:28:36'),(12,'സവാതന്ത്ര്യപൂർവ്വ ഭാരതത്തിൽ ദാരിദ്രരരഖ എന്ന ആശയം ഉയർത്തിക്കാണ്ടുവന്നത് ആര്','ഗാന്ധിജി  ','ജവഹർലാൽ','ദാദാഭായ് നവരറാജി','രവീന്ദ്രനാഥ ടാരഗാർ',NULL,'option2',6,0,0,0,0,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:28:36','2023-09-23 17:28:36'),(13,'സുഭാഷ് ചന്ദ്രര ാസിക്ന രനതാജി എന്നു വിരശഷിപ്പിചൃത്','ഗാന്ധിജി','ടാരഗാർ','രഗാപാല കൃഷ്ണ രഗാഖക്ല','വിൻസ്റ്റൺ ചർചൃിൽ',NULL,'option1',6,0,0,0,0,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:28:36','2023-09-23 17:28:36'),(14,'നിസ്സഹകരണ പ്രസ്ഥാനം പിൻവലികാനുള്ള കാരണം എന്താണ','വാഗൺ ട്രാജഡി','ജാലിയൻവാലാ ാഗ്','കാരകാരി ക്ട്രയിൻ സംഭവ','ചൗരി ചൗര സംഭവം',NULL,'option4',6,0,0,0,1,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:28:36','2023-09-23 17:28:36'),(15,'യൂണിയനും സംസ്ഥാനങ്ങൾക്കം രവണ്ടിയുള്ള പബ്ലിക് സർവീസ് കമ്മീഷനുകക്ള കുറിചൃ് പ്രതിപാദിക്കന്ന ആർട്ടികിൾ','312','315','316','317',NULL,'option2',6,0,0,0,0,0,2,3,0,1,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:28:36','2023-09-23 17:28:36'),(16,'കുളചൃൽ യുദ്ധം നടന്ന വർഷം','1747','1758','1767','1792',NULL,'option1',6,0,0,0,0,0,4,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:29:00','2023-09-23 17:29:00'),(17,'സവാതന്ത്ര്യപൂർവ്വ ഭാരതത്തിൽ ദാരിദ്രരരഖ എന്ന ആശയം ഉയർത്തിക്കാണ്ടുവന്നത് ആര്','ഗാന്ധിജി  ','ജവഹർലാൽ','ദാദാഭായ് നവരറാജി','രവീന്ദ്രനാഥ ടാരഗാർ',NULL,'option2',6,0,0,0,0,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:29:00','2023-09-23 17:29:00'),(18,'സുഭാഷ് ചന്ദ്രര ാസിക്ന രനതാജി എന്നു വിരശഷിപ്പിചൃത്','ഗാന്ധിജി','ടാരഗാർ','രഗാപാല കൃഷ്ണ രഗാഖക്ല','വിൻസ്റ്റൺ ചർചൃിൽ',NULL,'option1',6,0,0,0,0,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:29:00','2023-09-23 17:29:00'),(19,'നിസ്സഹകരണ പ്രസ്ഥാനം പിൻവലികാനുള്ള കാരണം എന്താണ','വാഗൺ ട്രാജഡി','ജാലിയൻവാലാ ാഗ്','കാരകാരി ക്ട്രയിൻ സംഭവ','ചൗരി ചൗര സംഭവം',NULL,'option4',6,0,0,0,1,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:29:00','2023-09-23 17:29:00'),(20,'യൂണിയനും സംസ്ഥാനങ്ങൾക്കം രവണ്ടിയുള്ള പബ്ലിക് സർവീസ് കമ്മീഷനുകക്ള കുറിചൃ് പ്രതിപാദിക്കന്ന ആർട്ടികിൾ','312','315','316','317',NULL,'option2',6,0,0,0,0,0,2,3,0,1,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:29:00','2023-09-23 17:29:00'),(21,'കുളചൃൽ യുദ്ധം നടന്ന വർഷം','1747','1758','1767','1792',NULL,'option1',6,0,0,0,0,0,4,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:29:23','2023-09-23 17:29:23'),(22,'സവാതന്ത്ര്യപൂർവ്വ ഭാരതത്തിൽ ദാരിദ്രരരഖ എന്ന ആശയം ഉയർത്തിക്കാണ്ടുവന്നത് ആര്','ഗാന്ധിജി  ','ജവഹർലാൽ','ദാദാഭായ് നവരറാജി','രവീന്ദ്രനാഥ ടാരഗാർ',NULL,'option2',6,0,0,0,0,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:29:23','2023-09-23 17:29:23'),(23,'സുഭാഷ് ചന്ദ്രര ാസിക്ന രനതാജി എന്നു വിരശഷിപ്പിചൃത്','ഗാന്ധിജി','ടാരഗാർ','രഗാപാല കൃഷ്ണ രഗാഖക്ല','വിൻസ്റ്റൺ ചർചൃിൽ',NULL,'option1',6,0,0,0,0,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:29:23','2023-09-23 17:29:23'),(24,'നിസ്സഹകരണ പ്രസ്ഥാനം പിൻവലികാനുള്ള കാരണം എന്താണ','വാഗൺ ട്രാജഡി','ജാലിയൻവാലാ ാഗ്','കാരകാരി ക്ട്രയിൻ സംഭവ','ചൗരി ചൗര സംഭവം',NULL,'option4',6,0,0,0,1,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:29:23','2023-09-23 17:29:23'),(25,'യൂണിയനും സംസ്ഥാനങ്ങൾക്കം രവണ്ടിയുള്ള പബ്ലിക് സർവീസ് കമ്മീഷനുകക്ള കുറിചൃ് പ്രതിപാദിക്കന്ന ആർട്ടികിൾ','312','315','316','317',NULL,'option2',6,0,0,0,0,0,2,3,0,1,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:29:23','2023-09-23 17:29:23'),(26,'കുളചൃൽ യുദ്ധം നടന്ന വർഷം','1747','1758','1767','1792',NULL,'option1',6,0,0,0,0,0,4,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:29:33','2023-09-23 17:29:33'),(27,'സവാതന്ത്ര്യപൂർവ്വ ഭാരതത്തിൽ ദാരിദ്രരരഖ എന്ന ആശയം ഉയർത്തിക്കാണ്ടുവന്നത് ആര്','ഗാന്ധിജി  ','ജവഹർലാൽ','ദാദാഭായ് നവരറാജി','രവീന്ദ്രനാഥ ടാരഗാർ',NULL,'option2',6,0,0,0,0,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:29:33','2023-09-23 17:29:33'),(28,'സുഭാഷ് ചന്ദ്രര ാസിക്ന രനതാജി എന്നു വിരശഷിപ്പിചൃത്','ഗാന്ധിജി','ടാരഗാർ','രഗാപാല കൃഷ്ണ രഗാഖക്ല','വിൻസ്റ്റൺ ചർചൃിൽ',NULL,'option1',6,0,0,0,0,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:29:33','2023-09-23 17:29:33'),(29,'നിസ്സഹകരണ പ്രസ്ഥാനം പിൻവലികാനുള്ള കാരണം എന്താണ','വാഗൺ ട്രാജഡി','ജാലിയൻവാലാ ാഗ്','കാരകാരി ക്ട്രയിൻ സംഭവ','ചൗരി ചൗര സംഭവം',NULL,'option4',6,0,0,0,1,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:29:33','2023-09-23 17:29:33'),(30,'യൂണിയനും സംസ്ഥാനങ്ങൾക്കം രവണ്ടിയുള്ള പബ്ലിക് സർവീസ് കമ്മീഷനുകക്ള കുറിചൃ് പ്രതിപാദിക്കന്ന ആർട്ടികിൾ','312','315','316','317',NULL,'option2',6,0,0,0,0,0,2,3,0,1,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:29:33','2023-09-23 17:29:33'),(31,'കുളചൃൽ യുദ്ധം നടന്ന വർഷം','1747','1758','1767','1792',NULL,'option1',6,0,0,0,0,0,4,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:30:42','2023-09-23 17:30:42'),(32,'സവാതന്ത്ര്യപൂർവ്വ ഭാരതത്തിൽ ദാരിദ്രരരഖ എന്ന ആശയം ഉയർത്തിക്കാണ്ടുവന്നത് ആര്','ഗാന്ധിജി  ','ജവഹർലാൽ','ദാദാഭായ് നവരറാജി','രവീന്ദ്രനാഥ ടാരഗാർ',NULL,'option2',6,0,0,0,0,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:30:42','2023-09-23 17:30:42'),(33,'സുഭാഷ് ചന്ദ്രര ാസിക്ന രനതാജി എന്നു വിരശഷിപ്പിചൃത്','ഗാന്ധിജി','ടാരഗാർ','രഗാപാല കൃഷ്ണ രഗാഖക്ല','വിൻസ്റ്റൺ ചർചൃിൽ',NULL,'option1',6,0,0,0,0,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:30:42','2023-09-23 17:30:42'),(34,'നിസ്സഹകരണ പ്രസ്ഥാനം പിൻവലികാനുള്ള കാരണം എന്താണ','വാഗൺ ട്രാജഡി','ജാലിയൻവാലാ ാഗ്','കാരകാരി ക്ട്രയിൻ സംഭവ','ചൗരി ചൗര സംഭവം',NULL,'option4',6,0,0,0,1,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:30:42','2023-09-23 17:30:42'),(35,'യൂണിയനും സംസ്ഥാനങ്ങൾക്കം രവണ്ടിയുള്ള പബ്ലിക് സർവീസ് കമ്മീഷനുകക്ള കുറിചൃ് പ്രതിപാദിക്കന്ന ആർട്ടികിൾ','312','315','316','317',NULL,'option2',6,0,0,0,0,0,2,3,0,1,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:30:42','2023-09-23 17:30:42'),(36,'കുളചൃൽ യുദ്ധം നടന്ന വർഷം','1747','1758','1767','1792',NULL,'option1',6,0,0,0,0,0,4,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:30:52','2023-09-23 17:30:52'),(37,'സവാതന്ത്ര്യപൂർവ്വ ഭാരതത്തിൽ ദാരിദ്രരരഖ എന്ന ആശയം ഉയർത്തിക്കാണ്ടുവന്നത് ആര്','ഗാന്ധിജി  ','ജവഹർലാൽ','ദാദാഭായ് നവരറാജി','രവീന്ദ്രനാഥ ടാരഗാർ',NULL,'option2',6,0,0,0,0,0,2,3,0,0,0,0,0,'5','10','en',1,1,1,1,'2023-09-23 17:30:52','2023-09-23 17:30:52'),(39,'നിസ്സഹകരണ പ്രസ്ഥാനം പിൻവലികാനുള്ള കാരണം എന്താണ','വാഗൺ ട്രാജഡി','ജാലിയൻവാലാ ാഗ്','കാരകാരി ക്ട്രയിൻ സംഭവ','ചൗരി ചൗര സംഭവം',NULL,'option4',6,0,0,0,1,0,2,3,0,0,0,0,0,'5','10','en',0,1,1,1,'2023-09-23 17:30:52','2023-09-23 17:48:21');
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_req`
--

DROP TABLE IF EXISTS `quiz_req`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_req` (
  `quiz_req_id` int NOT NULL AUTO_INCREMENT,
  `user_agent` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ipaddress` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `region` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `score` smallint DEFAULT NULL,
  `mobile` smallint DEFAULT NULL,
  `otp` smallint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`quiz_req_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_req`
--

LOCK TABLES `quiz_req` WRITE;
/*!40000 ALTER TABLE `quiz_req` DISABLE KEYS */;
INSERT INTO `quiz_req` VALUES (1,'PostmanRuntime/7.33.0','61.135.188.23','Beijing','Beijing','CN',5,32767,3277,'2023-09-24 20:42:33','2023-09-24 20:42:33'),(2,'PostmanRuntime/7.33.0','61.135.188.23','Beijing','Beijing','CN',5,32767,8655,'2023-09-24 20:42:52','2023-09-24 20:42:52'),(3,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Sa','61.135.188.23','Beijing','Beijing','CN',2,32767,1838,'2023-09-25 08:14:25','2023-09-25 08:14:25'),(4,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Sa','61.135.188.23','Beijing','Beijing','CN',2,32767,6213,'2023-09-25 08:15:05','2023-09-25 08:15:05'),(5,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Sa','61.135.188.23','Beijing','Beijing','CN',3,32767,6064,'2023-09-25 10:51:30','2023-09-25 10:51:30');
/*!40000 ALTER TABLE `quiz_req` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_setup`
--

DROP TABLE IF EXISTS `quiz_setup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_setup` (
  `quiz_setup_id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `questionCount` text COLLATE utf8mb4_unicode_ci,
  `total_time` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`quiz_setup_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_setup`
--

LOCK TABLES `quiz_setup` WRITE;
/*!40000 ALTER TABLE `quiz_setup` DISABLE KEYS */;
INSERT INTO `quiz_setup` VALUES (2,'Quiz From Brilliance','5','10',NULL);
/*!40000 ALTER TABLE `quiz_setup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `section`
--

DROP TABLE IF EXISTS `section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `section` (
  `section_id` int NOT NULL AUTO_INCREMENT,
  `subject_id` smallint DEFAULT NULL,
  `name` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`section_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section`
--

LOCK TABLES `section` WRITE;
/*!40000 ALTER TABLE `section` DISABLE KEYS */;
INSERT INTO `section` VALUES (1,1,'section one'),(2,1,'section two'),(3,NULL,'REASONING ABILITY'),(4,NULL,'QUANTITATIVE APTITUD'),(5,3,'QUANTITATIVE APTITUD'),(6,NULL,'Sahithyam'),(7,3,'QUANTITATIVE APTITUD'),(8,3,'QUANTITATIVE APTITUD'),(9,3,'QUANTITATIVE APTITUD'),(10,3,'QUANTITATIVE APTITUD');
/*!40000 ALTER TABLE `section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stream`
--

DROP TABLE IF EXISTS `stream`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream` (
  `stream_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`stream_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stream`
--

LOCK TABLES `stream` WRITE;
/*!40000 ALTER TABLE `stream` DISABLE KEYS */;
INSERT INTO `stream` VALUES (6,'UPSC'),(7,'BANK');
/*!40000 ALTER TABLE `stream` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject`
--

DROP TABLE IF EXISTS `subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subject` (
  `subject_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`subject_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject`
--

LOCK TABLES `subject` WRITE;
/*!40000 ALTER TABLE `subject` DISABLE KEYS */;
INSERT INTO `subject` VALUES (1,'science'),(2,'English'),(3,'APTITUDE'),(4,'Malayalam');
/*!40000 ALTER TABLE `subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(100) NOT NULL,
  `notify` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'notifications by email',
  `last_login` int unsigned DEFAULT NULL,
  `user_type` varchar(20) DEFAULT NULL,
  `branch_id` varchar(15) DEFAULT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(20) DEFAULT NULL,
  `accessManagement_id` varchar(20) DEFAULT NULL,
  `address` varchar(20) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `whatsapp` varchar(20) DEFAULT NULL,
  `created_by` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `gender` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin@admin.com','5f4dcc3b5aa765d61d8327deb882cf99','admin@admin.com',0,1695637139,'admin',NULL,'admin',NULL,NULL,NULL,NULL,NULL,NULL,'2023-09-17 18:06:47','2023-09-25 10:18:59',NULL),(11,'','5f4dcc3b5aa765d61d8327deb882cf99','adminw@admin.com',0,NULL,'students','1','nithin','mps',NULL,'sgfdg','08610632556','08610632556',NULL,'2023-09-18 13:03:54','2023-09-18 13:03:54',NULL),(12,'','951e1e39aaeee43e665e6a27c8538c96','nithin@gmail.com',0,NULL,'students','Main Branch','Dulce','Abril',NULL,'United States','8610632556','8610632556',NULL,'2023-09-18 17:28:00','2023-09-18 17:28:00','Female'),(13,'','ce0cd4d8c83ab6011b74c8e5563ce2a6','nithins@gmail.com',0,NULL,'students','Main Branch','Mara','Hashimoto',NULL,'Great Britain',NULL,'25',NULL,'2023-09-18 17:28:00','2023-09-18 17:28:00','Female'),(14,'','3f2e2531201cfbf853f16f668132eaf2','2587',0,NULL,'students','Main Branch','Philip','Gent',NULL,'France',NULL,'36',NULL,'2023-09-18 17:28:00','2023-09-18 17:28:00','Male'),(15,'','1c4f297ff8012fc249cb1d8ece9c76f8','3549',0,NULL,'students','Main Branch','Kathleen','Hanner',NULL,'United States',NULL,'25',NULL,'2023-09-18 17:28:00','2023-09-18 17:28:00','Female'),(16,'','a24f37cb41d18c63ff0d04b041c7b539','2468',0,NULL,'students','Main Branch','Nereida','Magwood',NULL,'United States',NULL,'58',NULL,'2023-09-18 17:28:00','2023-09-18 17:28:00','Female'),(17,'','f5b13112b8169fb52bdcb60a98bc2911','2554',0,NULL,'students','Main Branch','Gaston','Brumm',NULL,'United States',NULL,'24',NULL,'2023-09-18 17:28:00','2023-09-18 17:28:00','Male'),(18,'','6f6b8a59b0d9b12dae70f9d3e0f294d7','3598',0,NULL,'students','Main Branch','Etta','Hurn',NULL,'Great Britain',NULL,'56',NULL,'2023-09-18 17:28:00','2023-09-18 17:28:00','Female'),(19,'','55a9ab74eba5fdd8726510ae8a83d00d','2456',0,NULL,'students','Main Branch','Earlean','Melgar',NULL,'United States',NULL,'27',NULL,'2023-09-18 17:28:00','2023-09-18 17:28:00','Female'),(20,'','f3d714b7637c8bd4d1d8a94193652f26','6548',0,NULL,'students','Main Branch','Vincenza','Weiland',NULL,'United States',NULL,'40',NULL,'2023-09-18 17:28:00','2023-09-18 17:28:00','Female'),(21,'','5f4dcc3b5aa765d61d8327deb882cf99','nithin@123.com',0,NULL,'staff','2','nithin','mps','1','sgfdg','08610632556','08610632556',NULL,'2023-09-18 17:50:29','2023-09-18 17:50:29',NULL),(22,'','1263a561e22de4bb517756bf80c75bda','nithinmp2k17@gmail.com',0,1695321042,'staff','2','nithin','mps','1','sgfdg','8610632556','8610632556',NULL,'2023-09-21 17:07:50','2023-09-21 18:30:42',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_public`
--

DROP TABLE IF EXISTS `users_public`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_public` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_public`
--

LOCK TABLES `users_public` WRITE;
/*!40000 ALTER TABLE `users_public` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_public` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `value_store`
--

DROP TABLE IF EXISTS `value_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `value_store` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `thekey` varchar(50) NOT NULL,
  `value` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key` (`thekey`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `value_store`
--

LOCK TABLES `value_store` WRITE;
/*!40000 ALTER TABLE `value_store` DISABLE KEYS */;
INSERT INTO `value_store` VALUES (1,'sitelogo','NewLogo.jpg'),(2,'navitext',''),(3,'footercopyright','Brillialce'),(4,'contactspage','Hello dear client'),(5,'footerContactAddr',''),(6,'footerContactEmail','support@shop.dev'),(7,'footerContactPhone',''),(8,'googleMaps','42.671840, 83.279163'),(9,'footerAboutUs',''),(10,'footerSocialFacebook',''),(11,'footerSocialTwitter',''),(12,'footerSocialGooglePlus',''),(13,'footerSocialPinterest',''),(14,'footerSocialYoutube',''),(16,'contactsEmailTo','contacts@shop.dev'),(17,'shippingOrder','1'),(18,'addJs',''),(19,'publicQuantity','0'),(20,'paypal_email',''),(21,'paypal_sandbox','0'),(22,'publicDateAdded','0'),(23,'googleApi',''),(24,'template','crow'),(25,'cashondelivery_visibility','1'),(26,'showBrands','0'),(27,'showInSlider','0'),(28,'codeDiscounts','1'),(29,'virtualProducts','0'),(30,'multiVendor','0'),(31,'outOfStock','0'),(32,'hideBuyButtonsOfOutOfStock','0'),(33,'moreInfoBtn',''),(34,'refreshAfterAddToCart','0');
/*!40000 ALTER TABLE `value_store` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-25 16:55:47
