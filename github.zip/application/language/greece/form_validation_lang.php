<?php 
$lang['required'] = 'Απαιτούμενα πεδία';
