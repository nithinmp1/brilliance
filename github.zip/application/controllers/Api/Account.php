<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';

class Account extends REST_Controller
{

    private $decodeData;

    public function __construct()
    {
        ini_set('display_errors', '1');
        ini_set('display_startup_errors', '1');
        error_reporting(E_ALL & ~E_DEPRECATED);
        parent::__construct();
        $this->load->library('input');
        $this->load->library('form_validation');
        $this->load->library('response');
    }

    public function login_post() {
        $this->load->library('form_validation');
        $_POST = $input;

        $this->form_validation->set_rules('email', 'email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'password', 'required');
        if ($this->form_validation->run() === false) {
            $errors = validation_errors();
            $this->response->apiResponse(
                [
                    'status' => false,
                    'message' => 'input validation failed',
                    'data'=> $errors
                ]
            );
        }

        $query = $this->db->get_where('users',['email' => $input['email']
        , 'password' => $input['password']]);

        if ($query->num_rows() > 0) {
            $account = $query->row();
            echo "<pre>";print_r($account);die;

        } else {
            $this->response->apiResponse(
                [
                    'status' => false,
                    'code' => 401,
                    'message' => 'authentication failed',
                    'data'=> $errors
                ]
            );
        }

    }

    private function receiveJsonData() {
        $json = file_get_contents('php://input');
        $data = json_decode($json);
        if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
            $this->response->apiResponse(
                [
                    'status' => false,
                    'message' => 'Invalid Json'
                ]
            );
        }
        return $data;
    }

    function getOtp_post() {
        $input = $this->receiveJsonData();
        $data = [
            'user_agent' => $_SERVER['HTTP_USER_AGENT'], 
            // 'ipaddress' => $_SERVER['REMOTE_ADDR']
            'ipaddress' => '61.135.188.23',
            'mobile' => $input->mobile,
            'score' => $input->score,
            'otp' => rand(1000, 9999) 
        ];

        $ipInfo = file_get_contents("http://ipinfo.io/{$data['ipaddress']}/json");
        if (isset($ipInfo) && $ipInfo != '') {
            $ipInfoData = json_decode($ipInfo);
            if (isset($ipInfoData) && !empty($ipInfoData)) {
                $data['city'] = $ipInfoData->city;
                $data['region'] = $ipInfoData->region;
                $data['country'] = $ipInfoData->country;
            }
        }
        $this->db->insert('quiz_req', $data);
        
        $this->response(
            [
                'status' => true,
            ]
            , REST_Controller::HTTP_OK); 
    }
    
    function checkOtp_post() {
        $input = $this->receiveJsonData();
        
        $quiz_req = $this->db->get_where('quiz_req',['mobile' => $input->mobile, 'otp' => $input->otp])->row();
        if (empty($quiz_req)) {
            $this->response(
                [
                    'status' => false,
                ]
                , REST_Controller::HTTP_OK); 
        }

        $specificTimestamp = strtotime($quiz_req->updated_at);

        $currentTimestamp = time();

        $timeDifference = $currentTimestamp - $specificTimestamp;
        // echo $timeDifference;die;
        if ($timeDifference > 30) {
            echo "The current time has exceeded 30 seconds from the specific time.";
        } else {
            echo "The current time is within 30 seconds from the specific time.";
        }

    }
}