<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends MY_Controller
{

    private $num_rows = 20;

    public function __construct()
    {
        parent::__construct();
        $this->load->library('guzzle');
    }

    public function index($page = 0)
    {
        $this->load->library('guzzle');
        $head = $data =[];
        $quiz = $this->guzzle->get(['method' => 'quiz']);
        $data['quiz'] = $quiz['quiz']; 
        $data['title'] = 'Quiz';
        $data['invokeUrl'] = site_url('get-otp');
        $data['loginUrl'] = site_url('login');
        $data['checkOtpUrl'] = site_url('check-otp');

        $this->render('home', $head, $data);
    }
}
