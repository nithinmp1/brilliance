<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Monolog\Logger;
use Monolog\Handler\StreamHandler;

class Log {
    private $logger;

    function __construct() {
        $this->logger = new Logger('my_logger');

        $this->logger->pushHandler(new StreamHandler('logfile.log', Logger::INFO));
    }

    function push(array $data) : array {
        $this->logger->error('An error occurred.', ['user_id' => 123, 'exception' => ['data' => 'error']]);
    }
}