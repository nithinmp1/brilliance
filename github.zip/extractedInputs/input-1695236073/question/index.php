<?php
/*
require '../../../vendor/autoload.php'; // Include PhpSpreadsheet autoload

use PhpOffice\PhpSpreadsheet\IOFactory;

$filePath = 'excel.xls'; // Replace with the path to your Excel file

// Load the Excel file
$spreadsheet = IOFactory::load($filePath);

// Get the active sheet (you can specify the sheet by name or index)
$worksheet = $spreadsheet->getActiveSheet();

// Initialize an array to store the Excel data
$data = [];

// Initialize a variable to store the header row values
$headerRow = [];

// Iterate through rows and columns
foreach ($worksheet->getRowIterator() as $row) {
    $rowData = [];
    foreach ($row->getCellIterator() as $cell) {
        $rowData[] = $cell->getValue();
    }
    
    // If it's the first row, store the values as headers
    if (empty($headerRow)) {
        $headerRow = $rowData;
    } else {
        // Otherwise, create an associative array with header keys
        $rowAssoc = [];
        foreach ($headerRow as $index => $header) {
            $rowAssoc[$header] = isset($rowData[$index]) ? $rowData[$index] : null;
        }
        $data[] = $rowAssoc;
    }
}

// Now, $data contains the Excel sheet data as an array with header keys
print_r($data);
*/
?>


<?php
require '../../../vendor/autoload.php'; // Include PhpSpreadsheet autoload

use PhpOffice\PhpSpreadsheet\IOFactory;
$filePath = 'excel.xls'; // Replace with the path to your Excel file


// Load the Excel file
$spreadsheet = IOFactory::load($filePath);

// Get the active sheet (you can specify the sheet by name or index)
$worksheet = $spreadsheet->getActiveSheet();

// Initialize an array to store the Excel data
$data = [];

// Iterate through rows and columns
foreach ($worksheet->getRowIterator() as $row) {
    $rowData = [];
    foreach ($row->getCellIterator() as $cell) {
        // Check if the cell is in a merged range
        $mergedCells = $worksheet->getMergeCells();
        
        var_dump( $mergedCells);die;
        if (in_array($cell->getCoordinate(), $mergedCells)) {
            die('here');
            // If the cell is in a merged range, get the value from the first cell of the range
            $range = $worksheet->getCell($cell->getCoordinate());
            $rowData[] = $range->getValue();
        } else {
            // If the cell is not in a merged range, get the value from the cell
            $rowData[] = $cell->getValue();
        }
    }
    $data[] = $rowData;
}

// Now, $data contains the Excel sheet data as an array with merged cells handled correctly
print_r($data);
?>
