<?php
require '../../../vendor/autoload.php'; // Include PhpSpreadsheet autoload

use PhpOffice\PhpSpreadsheet\IOFactory;
$filePath = 'excel.xls'; // Replace with the path to your Excel file


// Load the Excel file
$spreadsheet = IOFactory::load($filePath);

// Get the active sheet (you can specify the sheet by name or index)
$worksheet = $spreadsheet->getActiveSheet();

// Specify the current cell's coordinates
$currentRow = 2; // Replace with the row number of the current cell
$currentColumn = 'S'; // Replace with the column letter of the current cell

// Specify the range
$startRow = 2;
$endRow = 4;
$startColumn = 'S';
$endColumn = 'S';

// Check if the current cell is within the specified range
if ($currentRow >= $startRow && $currentRow <= $endRow && $currentColumn == $startColumn) {
    echo "The current cell is within the range S2:S4.";
} else {
    echo "The current cell is not within the range S2:S4.";
}
?>
