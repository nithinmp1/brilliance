<?php
require '../../../vendor/autoload.php'; // Include PhpSpreadsheet autoload

use PhpOffice\PhpSpreadsheet\IOFactory;
$filePath = 'excel.xls'; // Replace with the path to your Excel file

// Load the Excel file
$spreadsheet = IOFactory::load($filePath);

// Get the active sheet (you can specify the sheet by name or index)
$worksheet = $spreadsheet->getActiveSheet();

// Get all merged cell ranges
$mergedCells = $worksheet->getMergeCells();

// Initialize an array to store merged cell values
$mergedCellValues = [];

// Iterate through the merged cell ranges
foreach ($mergedCells as $mergedRange) {
    list($startCell, $endCell) = explode(':', $mergedRange);
    
    $startColumn = preg_replace('/[0-9]+/', '', $startCell);
    $startRow = (int)preg_replace('/[A-Z]+/', '', $startCell);
    
    $endColumn = preg_replace('/[0-9]+/', '', $endCell);
    $endRow = (int)preg_replace('/[A-Z]+/', '', $endCell);
    
    // Extract the value from the top-left cell of the merged range
    $value = $worksheet->getCell($startColumn . $startRow)->getValue();
    
    // Store the merged cell range and its value in the array
    $mergedCellValues[$mergedRange] = $value;
}

// Now, $mergedCellValues contains the merged cell ranges and their corresponding values
print_r($mergedCellValues);
?>
