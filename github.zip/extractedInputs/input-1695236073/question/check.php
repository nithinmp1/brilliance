<?php
require '../../../vendor/autoload.php'; // Include PhpSpreadsheet autoload

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

$filePath = 'excel.xls'; // Replace with the path to your Excel file

// Load the Excel file
$spreadsheet = IOFactory::load($filePath);

// Get the active sheet (you can specify the sheet by name or index)
$worksheet = $spreadsheet->getActiveSheet();

// Specify the cell address you want to check
$cellAddressToCheck = 'S2'; // Replace with the cell address you want to check

// Specify the range
$startCellAddress = 'S2';
$endCellAddress = 'S4';

// Extract the column and row from cell addresses
list($cellColumn, $cellRow) = Coordinate::coordinateFromString($cellAddressToCheck);
list($startColumn, $startRow) = Coordinate::coordinateFromString($startCellAddress);
list($endColumn, $endRow) = Coordinate::coordinateFromString($endCellAddress);

// Check if the cell address is within the specified range
if (
    $cellColumn === $startColumn && $cellRow >= $startRow && $cellRow <= $endRow
) {
    echo "The cell address $cellAddressToCheck is within the range $startCellAddress:$endCellAddress.";
} else {
    echo "The cell address $cellAddressToCheck is not within the range $startCellAddress:$endCellAddress.";
}
?>
