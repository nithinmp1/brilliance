# smis

https://routesnroots.in/dschoolcrs/
admin@example.com
admin123

staff

staff@gmail.com
staff@123#5

Changes

1. Vehicle admin 1hr 
    started 19:11 22:19 dinner distractions 1:30
2. class admin 1hr 
3. Instructor admin 1hr No additional works
4. staff login access permission 2hr 11:47 - 12:57,

4. student admin 3hr
5. customer admin 2hr
6. report
7. expence 
8. Attendance
8. account dashboard
9. instructor dashboard


https://routesnroots.in/dcrm/index.php?admin/testEditor

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